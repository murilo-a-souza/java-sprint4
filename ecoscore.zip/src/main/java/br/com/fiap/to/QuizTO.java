package br.com.fiap.to;

import jakarta.validation.constraints.*;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Uma atividade criada pelo usuário, capaz de gerar pontos
 * @since Java 21
 */
public class QuizTO {
    @Positive(message = "Valor do id não pode ser negativo")
    @Null(message = "Valor não pode ser vazio")
    private Integer idQuiz;
    @Size(max = 30, message = "IDs de usuário tem no máximo 30 caracteres")
    @NotBlank(message = "Valor não pode ser vazio")
    private String idUsuario;
    @Min(value = 0, message = "Valor não pode ser negativo")
    @NotNull(message = "Valor não pode ser vazio")
    private int numQuestoes;
    @Min(value = 0, message = "Valor não pode ser negativo")
    @NotNull(message = "Valor não pode ser vazio")
    private int numAcertos;
    @Min(value = 0, message = "Valor não pode ser negativo")
    private int qtPontosPorQuestao = 0;
    private int qtPontosGerados;
    @PastOrPresent(message = "O quiz não pode ter sido realizado no futuro")
    private LocalDateTime dtQuiz;

    public QuizTO() {
        this.dtQuiz = LocalDateTime.now();
    }
    public QuizTO(Integer idQuiz, String idUsuario, int numQuestoes, int numAcertos, int qtPontosPorQuestao) {
        this.idQuiz = idQuiz;
        this.idUsuario = idUsuario;
        setNumQuestoes(numQuestoes);
        setNumAcertos(numAcertos);
        setQtPontosPorQuestao(qtPontosPorQuestao);
        setQtPontosGerados();
        this.dtQuiz = LocalDateTime.now();
    }

    public Integer getIdQuiz() {
        return idQuiz;
    }
    public void setIdQuiz(Integer idQuiz) throws IllegalArgumentException{
        if (idQuiz < 0) { //não pode ser negativo
            throw new IllegalArgumentException("Valor do ID não pode ser negativo.");
        }
        this.idQuiz = idQuiz;
    }
    public String getIdUsuario() {
        return idUsuario;
    }
    public void setIdUsuario(String idUsuario) throws IllegalArgumentException{
        //máx 30 caracteres no banco
        if (idUsuario.length() > 30) {
            throw new IllegalArgumentException("Limite de caracteres é 30");
        }
        this.idUsuario = idUsuario.toLowerCase();
    }
    public int getNumQuestoes() {
        return numQuestoes;
    }
    public void setNumQuestoes(int numQuestoes) throws IllegalArgumentException {
        if (numQuestoes <= 0) {
            throw new IllegalArgumentException("A qtde. de questões deve ser maior que zero.");
        }
        this.numQuestoes = numQuestoes;
    }
    public int getNumAcertos() {
        return numAcertos;
    }
    public void setNumAcertos(int numAcertos) throws IllegalArgumentException {
        if (numAcertos < 0 || numAcertos > numQuestoes) {
            throw new IllegalArgumentException("A qtde. questões deve ser maior que zero e menor que o número de questões");
        }
        this.numAcertos = numAcertos;
    }
    public int getQtPontosPorQuestao() {
        return qtPontosPorQuestao;
    }
    public void setQtPontosPorQuestao(int qtPontosPorQuestao) throws IllegalArgumentException {
        if (qtPontosPorQuestao <= 0) {
            throw new IllegalArgumentException("A qtde. de pontos por questão deve ser maior que zero.");
        }
        this.qtPontosPorQuestao = qtPontosPorQuestao;
    }
    public int getQtPontosGerados() {
        return qtPontosGerados;
    }
    public void setQtPontosGerados() {
        //depende dos valores da própria classe.
        this.qtPontosGerados = numAcertos * qtPontosPorQuestao;
    }
    public LocalDateTime getDtQuiz() {
        return dtQuiz;
    }
    public void setDtQuiz(LocalDateTime dtQuiz) {
        this.dtQuiz = dtQuiz;
    }

    /**
     * Serve para retornar ao usuário quantos pontos essa atividade gerou
     * @return a quantidade de acertos vezes o quanto cada ponto vale
     */
    public int registrarPontos() {
        if (dtQuiz == null) {
            dtQuiz = LocalDateTime.now();
        }
        setQtPontosGerados(); //se o objeto não for criado com construtor com passagem.
        return qtPontosGerados;
    }

    /**
     * Gera uma descrição da atividade
     * @return Uma formatação com data e número de pontos gerados
     */
    public String detalhesQuiz() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm:ss");
        return String.format("Um quiz foi realizada em (%s), acertando %d/%d.", dtQuiz.format(dtf), numAcertos, numQuestoes);
    }
}
